<!DOCTYPE html>
<html lang="en">
<head>
<title>Katta</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
<link rel="stylesheet" href="Styles.css">
</head>
<body>

<h2>Bilde av katta</h2>
<p>Her er bildet</p>

<header>
  <h2>Bilder</h2>
  <?php
  echo "Dato: " . date("d-m-Y");
  ?>
</header>


<section>
<?php include 'nav.php' ?>
  
  <article>
    
<img src="Katta.png" alt="">
  </article>
</section>

<footer>
  <p>Dette var bildet</p>
</footer>

</body>
</html>
