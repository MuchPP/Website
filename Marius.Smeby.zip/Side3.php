<!DOCTYPE html>
<html lang="en">
<head>
<title>Kontaktinfo</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    
</style>
<link rel="stylesheet" href="Styles.css">
</head>
<body>

<h2>Kontaktinfo</h2>
<p>Her er litt kontaktinfo</p>

<header>
  <h2>Kontaktinfo</h2>
  <?php
  echo "Dato: " . date("d-m-Y");
  ?>
</header>

<section>
<?php include 'nav.php' ?>
  
  <article>
    <h1>Personalia</h1>
    <p>Jeg heter Marius. O. Smeby</p>
    <p>Telefon nummeret mitt er 46512447</p>
    <p>Personlig mail er: smebymarius01@gmail.com</p>
    <p>Annen mail er: marsme8skole@gmail.com</p>
  </article>
</section>

<footer>
  <p>Her er kontaktinfoen min</p>
</footer>

</body>
</html>
