<nav>
      <h2>Sider</h2>
    <ul>
      <li><a href="Index.php">Hamar Katedralskole</a></li>
      <li><a href="Side1.php">Data og Elektronikk systemer</a></li>
      <li><a href="Side2.php">Fag</a></li>
      <li><a href="Side3.php">KontaktInfo</a></li>
    </ul>
  </nav>