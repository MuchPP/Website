<!DOCTYPE html>
<html lang="en">
<head>
<title>Fag</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
<link rel="stylesheet" href="Styles.css">
</head>
<body>

<h2>Her er fagene jeg har</h2>


<header>
  <h2>Mine fag</h2>
  <?php
  echo "Dato: " . date("d-m-Y");
  ?>
</header>

<section>
<?php include 'nav.php' ?>
  
  <article>
    <h1>Fag</h1>
    <p>Elektronisk infrastruktur</p>
    <p>Engelsk</p>
    <p>Norsk</p>
    <p>Samfunnsfag</p>
    <p>Gym</p>
    <p>Data og elektronikk</p>
  </article>
</section>

<footer>
  <p>Dette er fagene jeg har</p>
</footer>

</body>
</html>
