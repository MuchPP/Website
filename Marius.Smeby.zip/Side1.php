<!DOCTYPE html>
<html lang="en">
<head>
<title>Data og elektronikk</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
<link rel="stylesheet" href="Styles.css">
</head>
<body>

<h2>Data og elektronikk</h2>


<header>
  <h2>Data og elektronikk</h2>
  <?php
  echo "Dato: " . date("d-m-Y");
  ?>
</header>

<section>
<?php include 'nav.php' ?>


  <article>
    <h1>Data og elektronikk</h1>
    <p></p>
    <p></p>
  </article>
</section>

<footer>
  <p>Data og elektronikk</p>
</footer>

</body>
</html>
